package cn.i7mc.sagadungeons.gui;

import cn.i7mc.sagadungeons.SagaDungeons;
import cn.i7mc.sagadungeons.model.DungeonTemplate;
import cn.i7mc.sagadungeons.util.MessageUtil;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 模板奖励系统编辑界面
 * 用于编辑模板的奖励系统
 */
public class TemplateRewardsEditGUI extends AbstractGUI {

    private final String templateName;
    private final DungeonTemplate template;

    /**
     * 构造函数
     * @param plugin 插件实例
     * @param player 玩家
     * @param templateName 模板名称
     */
    public TemplateRewardsEditGUI(SagaDungeons plugin, Player player, String templateName) {
        super(plugin, player, plugin.getConfigManager().getGUILanguageManager().getGUIText("template-rewards-edit.title")
                .replace("{template}", templateName), 54);
        this.templateName = templateName;
        this.template = plugin.getConfigManager().getTemplateManager().getTemplates().get(templateName);
    }

    @Override
    public void init() {
        // 检查模板是否存在
        if (template == null) {
            MessageUtil.sendMessage(player, "command.admin.edit.template-not-found",
                    MessageUtil.createPlaceholders("template", templateName));
            close();
            return;
        }

        // 清空界面
        inventory.clear();

        // 添加装饰边框
        addBorder();

        // 添加奖励编辑选项
        addRewardOptions();

        // 添加功能按钮
        addFunctionButtons();
    }

    /**
     * 添加装饰边框
     */
    private void addBorder() {
        ItemStack borderItem = new ItemBuilder(Material.PURPLE_STAINED_GLASS_PANE)
                .setName(getGUIText("common.border"))
                .build();

        // 上下边框
        for (int i = 0; i < 9; i++) {
            inventory.setItem(i, borderItem);
            inventory.setItem(45 + i, borderItem);
        }

        // 左右边框
        for (int i = 1; i < 5; i++) {
            inventory.setItem(i * 9, borderItem);
            inventory.setItem(i * 9 + 8, borderItem);
        }
    }

    /**
     * 添加奖励编辑选项
     */
    private void addRewardOptions() {
        // 基础奖励区域 (第二行)
        addBasicRewards();

        // 高级奖励区域 (第三行)
        addAdvancedRewards();

        // 时间奖励区域 (第四行)
        addTimeRewards();
    }

    /**
     * 添加基础奖励选项
     */
    private void addBasicRewards() {
        // 金币奖励
        ItemStack moneyRewardItem = new ItemBuilder(Material.GOLD_NUGGET)
                .setName(getGUIText("template-rewards-edit.money-reward"))
                .setLore(createBasicRewardLore("money", getGUIText("template-rewards-edit.money-reward")))
                .build();
        inventory.setItem(10, moneyRewardItem);

        // 点券奖励
        ItemStack pointsRewardItem = new ItemBuilder(Material.EMERALD)
                .setName(getGUIText("template-rewards-edit.points-reward"))
                .setLore(createBasicRewardLore("points", getGUIText("template-rewards-edit.points-reward")))
                .build();
        inventory.setItem(12, pointsRewardItem);

        // 经验奖励
        ItemStack expRewardItem = new ItemBuilder(Material.EXPERIENCE_BOTTLE)
                .setName(getGUIText("template-rewards-edit.exp-reward"))
                .setLore(createBasicRewardLore("experience", getGUIText("template-rewards-edit.exp-reward")))
                .build();
        inventory.setItem(14, expRewardItem);
    }

    /**
     * 添加高级奖励选项
     */
    private void addAdvancedRewards() {
        // 物品奖励
        ItemStack itemRewardItem = new ItemBuilder(Material.CHEST)
                .setName(getGUIText("template-rewards-edit.item-rewards"))
                .setLore(
                        getGUIText("template-rewards-edit.item-rewards-desc"),
                        getGUIText("template-rewards-edit.item-rewards-count").replace("{count}", String.valueOf(getItemRewardCount())),
                        "",
                        getGUIText("common.left-click") + getGUIText("template-rewards-edit.item-rewards-manage"),
                        getGUIText("template-rewards-edit.item-rewards-manage")
                )
                .build();
        inventory.setItem(19, itemRewardItem);

        // 命令奖励
        ItemStack commandRewardItem = new ItemBuilder(Material.COMMAND_BLOCK)
                .setName(getGUIText("template-rewards-edit.command-rewards"))
                .setLore(
                        getGUIText("template-rewards-edit.command-rewards-desc"),
                        getGUIText("template-rewards-edit.command-rewards-count").replace("{count}", String.valueOf(getCommandRewardCount())),
                        "",
                        getGUIText("common.left-click") + getGUIText("template-rewards-edit.command-rewards-manage"),
                        getGUIText("template-rewards-edit.command-rewards-manage")
                )
                .build();
        inventory.setItem(21, commandRewardItem);
    }

    /**
     * 添加时间奖励选项
     */
    private void addTimeRewards() {
        // 时间奖励管理
        ItemStack timeRewardItem = new ItemBuilder(Material.CLOCK)
                .setName(getGUIText("template-rewards-edit.time-rewards"))
                .setLore(createTimeRewardLore())
                .build();
        inventory.setItem(31, timeRewardItem);
    }

    /**
     * 创建基础奖励说明
     */
    private List<String> createBasicRewardLore(String rewardType, String displayName) {
        List<String> lore = new ArrayList<>();

        // 根据奖励类型获取描述
        String descKey = "";
        String inputKey = "";
        String clearKey = "";

        switch (rewardType) {
            case "money":
                descKey = "template-rewards-edit.money-reward-desc";
                inputKey = "template-rewards-edit.money-input-lore";
                clearKey = "template-rewards-edit.money-clear-lore";
                break;
            case "points":
                descKey = "template-rewards-edit.points-reward-desc";
                inputKey = "template-rewards-edit.points-input-lore";
                clearKey = "template-rewards-edit.points-clear-lore";
                break;
            case "experience":
                descKey = "template-rewards-edit.exp-reward-desc";
                inputKey = "template-rewards-edit.exp-input-lore";
                clearKey = "template-rewards-edit.exp-clear-lore";
                break;
        }

        lore.add(getGUIText(descKey));

        // 获取当前奖励值
        String currentValue = getCurrentRewardValue(rewardType);
        lore.add(getGUIText("common.current-value").replace("{value}", currentValue));
        lore.add("");
        lore.add(getGUIText("common.left-click") + getGUIText(inputKey));
        lore.add(getGUIText(inputKey));
        lore.add(getGUIText("common.right-click") + getGUIText(clearKey));

        return lore;
    }

    /**
     * 创建时间奖励说明
     */
    private List<String> createTimeRewardLore() {
        List<String> lore = new ArrayList<>();
        lore.add(getGUIText("template-rewards-edit.time-rewards-desc"));
        lore.add(getGUIText("template-rewards-edit.time-rewards-desc2"));
        lore.add("");

        if (template.hasTimeRewards()) {
            lore.add(getGUIText("template-rewards-edit.time-rewards-current"));
            for (Map.Entry<Integer, List<String>> entry : template.getTimeRewards().entrySet()) {
                int timeSeconds = entry.getKey();
                int commandCount = entry.getValue().size();
                lore.add(getGUIText("template-rewards-edit.time-rewards-item")
                        .replace("{time}", String.valueOf(timeSeconds))
                        .replace("{count}", String.valueOf(commandCount)));
            }
        } else {
            lore.add(getGUIText("template-rewards-edit.time-rewards-none"));
        }

        lore.add("");
        lore.add(getGUIText("common.left-click") + getGUIText("template-rewards-edit.time-rewards-manage"));
        lore.add(getGUIText("template-rewards-edit.time-rewards-manage"));

        return lore;
    }

    /**
     * 获取当前奖励值
     */
    private String getCurrentRewardValue(String rewardType) {
        try {
            File templateDir = plugin.getConfigManager().getTemplateManager().getTemplateDirectory(templateName);
            File configFile = new File(templateDir, "config.yml");

            if (!configFile.exists()) {
                return getGUIText("template-rewards-edit.not-configured");
            }

            YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
            ConfigurationSection rewardsSection = config.getConfigurationSection("rewards");

            if (rewardsSection == null) {
                return getGUIText("template-rewards-edit.not-configured");
            }

            switch (rewardType) {
                case "money":
                    if (rewardsSection.contains("money")) {
                        double money = rewardsSection.getDouble("money", 0.0);
                        return money > 0 ? String.valueOf(money) : getGUIText("template-rewards-edit.not-configured");
                    }
                    return getGUIText("template-rewards-edit.not-configured");

                case "points":
                    if (rewardsSection.contains("points")) {
                        int points = rewardsSection.getInt("points", 0);
                        return points > 0 ? String.valueOf(points) : getGUIText("template-rewards-edit.not-configured");
                    }
                    return getGUIText("template-rewards-edit.not-configured");

                case "experience":
                    if (rewardsSection.contains("experience")) {
                        int experience = rewardsSection.getInt("experience", 0);
                        return experience > 0 ? String.valueOf(experience) : getGUIText("template-rewards-edit.not-configured");
                    }
                    return getGUIText("template-rewards-edit.not-configured");

                default:
                    return getGUIText("template-rewards-edit.unknown");
            }
        } catch (Exception e) {
            cn.i7mc.sagadungeons.util.DebugUtil.debug("template-rewards.read-config-error",
                    cn.i7mc.sagadungeons.util.DebugUtil.createPlaceholders("template", templateName, "message", e.getMessage()));
            return getGUIText("template-rewards-edit.read-failed");
        }
    }

    /**
     * 获取物品奖励数量
     */
    private int getItemRewardCount() {
        try {
            File templateDir = plugin.getConfigManager().getTemplateManager().getTemplateDirectory(templateName);
            File configFile = new File(templateDir, "config.yml");

            if (!configFile.exists()) {
                return 0;
            }

            YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
            ConfigurationSection rewardsSection = config.getConfigurationSection("rewards");

            if (rewardsSection == null) {
                return 0;
            }

            ConfigurationSection itemsSection = rewardsSection.getConfigurationSection("items");
            if (itemsSection != null) {
                Set<String> keys = itemsSection.getKeys(false);
                return keys.size();
            }

            return 0;
        } catch (Exception e) {
            cn.i7mc.sagadungeons.util.DebugUtil.debug("template-rewards.read-item-count-error",
                    cn.i7mc.sagadungeons.util.DebugUtil.createPlaceholders("template", templateName, "message", e.getMessage()));
            return 0;
        }
    }

    /**
     * 获取命令奖励数量
     */
    private int getCommandRewardCount() {
        try {
            File templateDir = plugin.getConfigManager().getTemplateManager().getTemplateDirectory(templateName);
            File configFile = new File(templateDir, "config.yml");

            if (!configFile.exists()) {
                return 0;
            }

            YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
            ConfigurationSection rewardsSection = config.getConfigurationSection("rewards");

            if (rewardsSection == null) {
                return 0;
            }

            if (rewardsSection.contains("commands")) {
                List<String> commands = rewardsSection.getStringList("commands");
                return commands.size();
            }

            return 0;
        } catch (Exception e) {
            cn.i7mc.sagadungeons.util.DebugUtil.debug("template-rewards.read-command-count-error",
                    cn.i7mc.sagadungeons.util.DebugUtil.createPlaceholders("template", templateName, "message", e.getMessage()));
            return 0;
        }
    }

    /**
     * 添加功能按钮
     */
    private void addFunctionButtons() {
        // 保存按钮
        ItemStack saveButton = new ItemBuilder(Material.EMERALD)
                .setName(getGUIText("template-rewards-edit.save-button"))
                .setLore(
                        getGUIText("template-rewards-edit.save-button-desc"),
                        "",
                        getGUIText("template-rewards-edit.save-button-click")
                )
                .build();
        inventory.setItem(49, saveButton);

        // 返回按钮
        ItemStack backButton = new ItemBuilder(Material.ARROW)
                .setName(getGUIText("template-rewards-edit.back-button"))
                .setLore(getGUIText("template-rewards-edit.back-button-desc"))
                .build();
        inventory.setItem(45, backButton);

        // 刷新按钮
        ItemStack refreshButton = new ItemBuilder(Material.LIME_DYE)
                .setName(getGUIText("template-rewards-edit.refresh-button"))
                .setLore(getGUIText("template-rewards-edit.refresh-button-desc"))
                .build();
        inventory.setItem(53, refreshButton);
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        event.setCancelled(true);

        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType() == Material.AIR) {
            return;
        }

        int slot = event.getSlot();

        // 处理功能按钮
        switch (slot) {
            case 49: // 保存
                handleSave();
                return;
            case 45: // 返回
                handleBack();
                return;
            case 53: // 刷新
                init();
                return;
            case 10: // 金币奖励
                handleMoneyReward(event);
                return;
            case 12: // 点券奖励
                handlePointsReward(event);
                return;
            case 14: // 经验奖励
                handleExperienceReward(event);
                return;
            case 19: // 物品奖励
                handleItemReward();
                return;
            case 21: // 命令奖励
                handleCommandReward();
                return;
            case 31: // 时间奖励
                handleTimeReward();
                return;
        }
    }

    /**
     * 处理保存
     */
    private void handleSave() {
        plugin.getConfigManager().getTemplateManager().saveTemplate(template);

        // 保存后重新加载模板，确保内存中的模板与配置文件同步
        plugin.getConfigManager().getTemplateManager().reloadTemplate(templateName);

        MessageUtil.sendMessage(player, "command.admin.edit.save-success",
                MessageUtil.createPlaceholders("template", templateName));
    }

    /**
     * 处理返回
     */
    private void handleBack() {
        close();
        plugin.getGUIManager().openTemplateBasicEditGUI(player, templateName);
    }

    /**
     * 处理金币奖励
     */
    private void handleMoneyReward(InventoryClickEvent event) {
        if (event.isLeftClick()) {
            close();
            plugin.getChatInputListener().requestDecimalInput(player, "command.admin.edit.input-money-reward", input -> {
                // 使用BukkitScheduler确保在主线程中执行
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    // 设置金币奖励
                    double moneyReward = Double.parseDouble(input);
                    // TODO: 设置金币奖励到模板配置
                    MessageUtil.sendMessage(player, "command.admin.edit.money-reward-updated",
                            MessageUtil.createPlaceholders("reward", input));
                    // 重新打开界面
                    plugin.getGUIManager().openTemplateRewardsEditGUI(player, templateName);
                });
            });
        } else if (event.isRightClick()) {
            // 清除金币奖励
            // TODO: 清除金币奖励配置
            MessageUtil.sendMessage(player, "command.admin.edit.money-reward-cleared");
            init(); // 刷新界面
        }
    }

    /**
     * 处理点券奖励
     */
    private void handlePointsReward(InventoryClickEvent event) {
        if (event.isLeftClick()) {
            close();
            plugin.getChatInputListener().requestNumberInput(player, "command.admin.edit.input-points-reward", input -> {
                // 使用BukkitScheduler确保在主线程中执行
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    // 设置点券奖励
                    int pointsReward = Integer.parseInt(input);
                    // TODO: 设置点券奖励到模板配置
                    MessageUtil.sendMessage(player, "command.admin.edit.points-reward-updated",
                            MessageUtil.createPlaceholders("reward", input));
                    // 重新打开界面
                    plugin.getGUIManager().openTemplateRewardsEditGUI(player, templateName);
                });
            });
        } else if (event.isRightClick()) {
            // 清除点券奖励
            // TODO: 清除点券奖励配置
            MessageUtil.sendMessage(player, "command.admin.edit.points-reward-cleared");
            init(); // 刷新界面
        }
    }

    /**
     * 处理经验奖励
     */
    private void handleExperienceReward(InventoryClickEvent event) {
        if (event.isLeftClick()) {
            close();
            plugin.getChatInputListener().requestNumberInput(player, "command.admin.edit.input-experience-reward", input -> {
                // 使用BukkitScheduler确保在主线程中执行
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    // 设置经验奖励
                    int experienceReward = Integer.parseInt(input);
                    // TODO: 设置经验奖励到模板配置
                    MessageUtil.sendMessage(player, "command.admin.edit.experience-reward-updated",
                            MessageUtil.createPlaceholders("reward", input));
                    // 重新打开界面
                    plugin.getGUIManager().openTemplateRewardsEditGUI(player, templateName);
                });
            });
        } else if (event.isRightClick()) {
            // 清除经验奖励
            // TODO: 清除经验奖励配置
            MessageUtil.sendMessage(player, "command.admin.edit.experience-reward-cleared");
            init(); // 刷新界面
        }
    }

    /**
     * 处理物品奖励
     */
    private void handleItemReward() {
        close();
        // 打开物品奖励管理界面
        plugin.getGUIManager().openItemRewardManageGUI(player, templateName);
    }

    /**
     * 处理命令奖励
     */
    private void handleCommandReward() {
        close();
        // 打开命令奖励管理界面
        plugin.getGUIManager().openCommandRewardManageGUI(player, templateName);
    }

    /**
     * 处理时间奖励
     */
    private void handleTimeReward() {
        close();
        // 打开时间奖励管理界面
        plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
    }
}
