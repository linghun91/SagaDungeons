package cn.i7mc.sagadungeons.gui;

import cn.i7mc.sagadungeons.SagaDungeons;
import cn.i7mc.sagadungeons.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.*;

/**
 * 时间奖励管理界面
 * 管理副本模板的时间奖励配置
 */
public class TimeRewardManageGUI extends AbstractGUI {

    private final String templateName;
    private List<TimeRewardEntry> timeRewards;

    /**
     * 构造函数
     * @param plugin 插件实例
     * @param player 玩家
     * @param templateName 模板名称
     */
    public TimeRewardManageGUI(SagaDungeons plugin, Player player, String templateName) {
        super(plugin, player, plugin.getConfigManager().getGUILanguageManager().getGUIText("time-reward-manage.title",
                MessageUtil.createPlaceholders("template", templateName)), 54);
        this.templateName = templateName;
        this.timeRewards = new ArrayList<>();
    }

    @Override
    public void init() {
        // 清空界面
        inventory.clear();

        // 加载时间奖励数据
        loadTimeRewards();

        // 添加边框
        addBorder();

        // 添加功能按钮
        addFunctionButtons();

        // 显示时间奖励
        displayTimeRewards();
    }

    /**
     * 添加边框装饰
     */
    private void addBorder() {
        ItemStack borderItem = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE)
                .setName(getGUIText("common.border"))
                .build();

        // 上下边框
        for (int i = 0; i < 9; i++) {
            inventory.setItem(i, borderItem);
            inventory.setItem(45 + i, borderItem);
        }

        // 左右边框
        for (int i = 1; i < 5; i++) {
            inventory.setItem(i * 9, borderItem);
            inventory.setItem(i * 9 + 8, borderItem);
        }
    }

    /**
     * 添加功能按钮
     */
    private void addFunctionButtons() {
        // 添加时间奖励
        ItemStack addItem = new ItemBuilder(Material.EMERALD)
                .setName(getGUIText("time-reward-manage.add-time-reward"))
                .setLore(getGUITextList("time-reward-manage.add-time-reward-lore"))
                .build();
        inventory.setItem(46, addItem);

        // 返回按钮
        ItemStack backItem = new ItemBuilder(Material.ARROW)
                .setName(getGUIText("time-reward-manage.back-button"))
                .setLore(getGUITextList("time-reward-manage.back-button-lore"))
                .build();
        inventory.setItem(48, backItem);

        // 保存按钮
        ItemStack saveItem = new ItemBuilder(Material.WRITABLE_BOOK)
                .setName(getGUIText("time-reward-manage.save-config"))
                .setLore(getGUITextList("time-reward-manage.save-config-lore"))
                .build();
        inventory.setItem(49, saveItem);

        // 刷新按钮
        ItemStack refreshItem = new ItemBuilder(Material.COMPASS)
                .setName(getGUIText("time-reward-manage.refresh-interface"))
                .setLore(getGUITextList("time-reward-manage.refresh-interface-lore"))
                .build();
        inventory.setItem(50, refreshItem);

        // 清空所有奖励
        ItemStack clearItem = new ItemBuilder(Material.BARRIER)
                .setName(getGUIText("time-reward-manage.clear-all-rewards"))
                .setLore(getGUITextList("time-reward-manage.clear-all-rewards-lore"))
                .build();
        inventory.setItem(52, clearItem);
    }

    /**
     * 显示时间奖励
     */
    private void displayTimeRewards() {
        int startSlot = 10;
        int maxSlots = 7 * 4; // 4行，每行7个位置

        for (int i = 0; i < Math.min(timeRewards.size(), maxSlots); i++) {
            TimeRewardEntry entry = timeRewards.get(i);
            
            // 计算位置
            int row = i / 7;
            int col = i % 7;
            int slot = startSlot + row * 9 + col;

            // 创建时间奖励物品
            ItemStack rewardItem = createTimeRewardItem(entry, i);
            inventory.setItem(slot, rewardItem);
        }
    }

    /**
     * 创建时间奖励物品
     */
    private ItemStack createTimeRewardItem(TimeRewardEntry entry, int index) {
        List<String> lore = new ArrayList<>();

        // 时间限制信息
        Map<String, String> timePlaceholders = MessageUtil.createPlaceholders(
                "time", formatTime(entry.getTimeSeconds()),
                "seconds", String.valueOf(entry.getTimeSeconds())
        );
        lore.add(getGUIText("time-reward-manage.time-limit", timePlaceholders));

        // 命令数量信息
        Map<String, String> countPlaceholders = MessageUtil.createPlaceholders("count", String.valueOf(entry.getCommands().size()));
        lore.add(getGUIText("time-reward-manage.commands-count", countPlaceholders));
        lore.add("");

        if (!entry.getCommands().isEmpty()) {
            lore.add(getGUIText("time-reward-manage.commands-preview"));
            for (int i = 0; i < Math.min(entry.getCommands().size(), 3); i++) {
                String command = entry.getCommands().get(i);
                if (command.length() > 30) {
                    command = command.substring(0, 27) + "...";
                }
                Map<String, String> commandPlaceholders = MessageUtil.createPlaceholders("command", command);
                lore.add(getGUIText("time-reward-manage.command-item", commandPlaceholders));
            }
            if (entry.getCommands().size() > 3) {
                Map<String, String> morePlaceholders = MessageUtil.createPlaceholders("count", String.valueOf(entry.getCommands().size() - 3));
                lore.add(getGUIText("time-reward-manage.more-commands", morePlaceholders));
            }
        } else {
            lore.add(getGUIText("time-reward-manage.no-commands"));
        }

        lore.add("");
        lore.add(getGUIText("time-reward-manage.left-click-edit-time"));
        lore.add(getGUIText("time-reward-manage.shift-left-manage-commands"));
        lore.add(getGUIText("time-reward-manage.right-click-delete"));

        Map<String, String> titlePlaceholders = MessageUtil.createPlaceholders("index", String.valueOf(index + 1));
        return new ItemBuilder(Material.CLOCK)
                .setName(getGUIText("time-reward-manage.reward-info", titlePlaceholders))
                .setLore(lore)
                .build();
    }

    /**
     * 格式化时间显示
     */
    private String formatTime(int seconds) {
        if (seconds < 60) {
            Map<String, String> placeholders = MessageUtil.createPlaceholders("seconds", String.valueOf(seconds));
            return getGUIText("time-reward-manage.time-format-seconds", placeholders);
        } else if (seconds < 3600) {
            int minutes = seconds / 60;
            int remainingSeconds = seconds % 60;
            if (remainingSeconds > 0) {
                Map<String, String> placeholders = MessageUtil.createPlaceholders(
                        "minutes", String.valueOf(minutes),
                        "seconds", String.valueOf(remainingSeconds)
                );
                return getGUIText("time-reward-manage.time-format-minutes", placeholders);
            } else {
                Map<String, String> placeholders = MessageUtil.createPlaceholders("minutes", String.valueOf(minutes));
                return getGUIText("time-reward-manage.time-format-minutes-only", placeholders);
            }
        } else {
            int hours = seconds / 3600;
            int remainingMinutes = (seconds % 3600) / 60;
            if (remainingMinutes > 0) {
                Map<String, String> placeholders = MessageUtil.createPlaceholders(
                        "hours", String.valueOf(hours),
                        "minutes", String.valueOf(remainingMinutes)
                );
                return getGUIText("time-reward-manage.time-format-hours", placeholders);
            } else {
                Map<String, String> placeholders = MessageUtil.createPlaceholders("hours", String.valueOf(hours));
                return getGUIText("time-reward-manage.time-format-hours-only", placeholders);
            }
        }
    }

    /**
     * 加载时间奖励数据
     */
    private void loadTimeRewards() {
        timeRewards.clear();
        
        try {
            File templateFile = new File(plugin.getDataFolder(), "templates/" + templateName + ".yml");
            if (!templateFile.exists()) {
                return;
            }

            YamlConfiguration config = YamlConfiguration.loadConfiguration(templateFile);
            ConfigurationSection timeRewardsSection = config.getConfigurationSection("timeRewards");
            
            if (timeRewardsSection != null) {
                for (String timeKey : timeRewardsSection.getKeys(false)) {
                    try {
                        int timeSeconds = Integer.parseInt(timeKey);
                        ConfigurationSection timeRewardSection = timeRewardsSection.getConfigurationSection(timeKey);
                        
                        if (timeRewardSection != null) {
                            List<String> commands = timeRewardSection.getStringList("commands");
                            timeRewards.add(new TimeRewardEntry(timeSeconds, commands));
                        }
                    } catch (NumberFormatException e) {
                        plugin.getLogger().warning("Invalid time format: " + timeKey + " in template " + templateName);
                    }
                }
            }
            
            // 按时间排序
            timeRewards.sort(Comparator.comparingInt(TimeRewardEntry::getTimeSeconds));
            
        } catch (Exception e) {
            MessageUtil.sendMessage(player, "command.admin.edit.load-error");
            plugin.getLogger().warning("Error loading time rewards: " + e.getMessage());
        }
    }

    /**
     * 保存时间奖励数据
     */
    private void saveTimeRewards() {
        try {
            File templateFile = new File(plugin.getDataFolder(), "templates/" + templateName + ".yml");
            YamlConfiguration config = YamlConfiguration.loadConfiguration(templateFile);
            
            // 清除现有的时间奖励配置
            config.set("timeRewards", null);
            
            // 保存新的时间奖励配置
            if (!timeRewards.isEmpty()) {
                ConfigurationSection timeRewardsSection = config.createSection("timeRewards");
                
                for (TimeRewardEntry entry : timeRewards) {
                    ConfigurationSection timeSection = timeRewardsSection.createSection(String.valueOf(entry.getTimeSeconds()));
                    timeSection.set("commands", entry.getCommands());
                }
            }
            
            config.save(templateFile);
            
            // 重新加载模板配置
            plugin.getConfigManager().getTemplateManager().reloadTemplate(templateName);
            
        } catch (Exception e) {
            MessageUtil.sendMessage(player, "command.admin.edit.save-error");
            plugin.getLogger().warning("Error saving time rewards: " + e.getMessage());
        }
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        event.setCancelled(true);

        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType() == Material.AIR) {
            return;
        }

        int slot = event.getSlot();

        // 处理功能按钮
        switch (slot) {
            case 46: // 添加时间奖励
                handleAddTimeReward();
                return;
            case 48: // 返回
                handleBack();
                return;
            case 49: // 保存
                handleSave();
                return;
            case 50: // 刷新
                init();
                return;
            case 52: // 清空所有奖励
                if (event.isRightClick()) {
                    handleClearAll();
                }
                return;
        }

        // 处理时间奖励点击
        if (slot >= 10 && slot <= 34 && slot % 9 != 0 && slot % 9 != 8) {
            handleTimeRewardClick(event, slot);
        }
    }

    /**
     * 处理添加时间奖励
     */
    private void handleAddTimeReward() {
        close();
        plugin.getChatInputListener().requestNumberInput(player, "command.admin.edit.input-time-seconds", input -> {
            // 使用BukkitScheduler确保在主线程中执行
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                try {
                    int timeSeconds = Integer.parseInt(input);
                    if (timeSeconds <= 0) {
                        MessageUtil.sendMessage(player, "command.admin.edit.invalid-time-value");
                        plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                        return;
                    }

                    // 检查是否已存在相同时间的奖励
                    boolean exists = timeRewards.stream().anyMatch(entry -> entry.getTimeSeconds() == timeSeconds);
                    if (exists) {
                        MessageUtil.sendMessage(player, "command.admin.edit.time-reward-exists");
                        plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                        return;
                    }

                    // 添加新的时间奖励
                    timeRewards.add(new TimeRewardEntry(timeSeconds, new ArrayList<>()));
                    timeRewards.sort(Comparator.comparingInt(TimeRewardEntry::getTimeSeconds));

                    MessageUtil.sendMessage(player, "command.admin.edit.time-reward-added",
                            MessageUtil.createPlaceholders("time", formatTime(timeSeconds)));

                    // 重新打开界面
                    plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                } catch (NumberFormatException e) {
                    MessageUtil.sendMessage(player, "command.admin.edit.invalid-number");
                    plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                }
            });
        });
    }

    /**
     * 处理返回
     */
    private void handleBack() {
        close();
        plugin.getGUIManager().openTemplateRewardsEditGUI(player, templateName);
    }

    /**
     * 处理保存
     */
    private void handleSave() {
        saveTimeRewards();
        MessageUtil.sendMessage(player, "command.admin.edit.time-rewards-saved");
    }

    /**
     * 处理清空所有奖励
     */
    private void handleClearAll() {
        timeRewards.clear();
        init();
        MessageUtil.sendMessage(player, "command.admin.edit.all-time-rewards-cleared");
    }

    /**
     * 处理时间奖励点击
     */
    private void handleTimeRewardClick(InventoryClickEvent event, int slot) {
        // 计算时间奖励索引
        int row = slot / 9 - 1;
        int col = slot % 9 - 1;
        int index = row * 7 + col;

        if (index >= timeRewards.size()) {
            return;
        }

        TimeRewardEntry entry = timeRewards.get(index);

        if (event.isLeftClick()) {
            // 左键编辑时间限制
            handleEditTimeLimit(entry, index);
        } else if (event.isShiftClick() && event.isLeftClick()) {
            // Shift+左键管理奖励命令
            handleManageCommands(entry, index);
        } else if (event.isRightClick()) {
            // 右键删除
            handleDeleteTimeReward(index);
        }
    }

    /**
     * 处理编辑时间限制
     */
    private void handleEditTimeLimit(TimeRewardEntry entry, int index) {
        close();
        plugin.getChatInputListener().requestNumberInput(player, "command.admin.edit.input-new-time-seconds", input -> {
            // 使用BukkitScheduler确保在主线程中执行
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                try {
                    int newTimeSeconds = Integer.parseInt(input);
                    if (newTimeSeconds <= 0) {
                        MessageUtil.sendMessage(player, "command.admin.edit.invalid-time-value");
                        plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                        return;
                    }

                    // 检查是否已存在相同时间的奖励（排除当前编辑的）
                    boolean exists = timeRewards.stream()
                            .anyMatch(e -> e != entry && e.getTimeSeconds() == newTimeSeconds);
                    if (exists) {
                        MessageUtil.sendMessage(player, "command.admin.edit.time-reward-exists");
                        plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                        return;
                    }

                    // 更新时间限制
                    entry.setTimeSeconds(newTimeSeconds);
                    timeRewards.sort(Comparator.comparingInt(TimeRewardEntry::getTimeSeconds));

                    MessageUtil.sendMessage(player, "command.admin.edit.time-limit-updated",
                            MessageUtil.createPlaceholders("time", formatTime(newTimeSeconds)));

                    // 重新打开界面
                    plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                } catch (NumberFormatException e) {
                    MessageUtil.sendMessage(player, "command.admin.edit.invalid-number");
                    plugin.getGUIManager().openTimeRewardManageGUI(player, templateName);
                }
            });
        });
    }

    /**
     * 处理管理命令
     */
    private void handleManageCommands(TimeRewardEntry entry, int index) {
        close();
        // 打开时间奖励命令管理界面
        plugin.getGUIManager().openTimeRewardCommandGUI(player, templateName, entry.getTimeSeconds());
    }

    /**
     * 处理删除时间奖励
     */
    private void handleDeleteTimeReward(int index) {
        if (index >= 0 && index < timeRewards.size()) {
            TimeRewardEntry entry = timeRewards.get(index);
            timeRewards.remove(index);
            init();
            MessageUtil.sendMessage(player, "command.admin.edit.time-reward-deleted",
                    MessageUtil.createPlaceholders("time", formatTime(entry.getTimeSeconds())));
        }
    }

    /**
     * 时间奖励条目类
     */
    private static class TimeRewardEntry {
        private int timeSeconds;
        private List<String> commands;

        public TimeRewardEntry(int timeSeconds, List<String> commands) {
            this.timeSeconds = timeSeconds;
            this.commands = new ArrayList<>(commands);
        }

        public int getTimeSeconds() {
            return timeSeconds;
        }

        public void setTimeSeconds(int timeSeconds) {
            this.timeSeconds = timeSeconds;
        }

        public List<String> getCommands() {
            return commands;
        }


    }
}
